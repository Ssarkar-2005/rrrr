import sqlite3
import random

cities = ['Delhi', 'Mumbai', 'Chennai', 'Bengaluru', 'Kolkata', 'Hyderabad', 'Ahmedabad', 'Pune', 'Jaipur', 'Lucknow']
train_prefixes = ['Rajdhani', 'Shatabdi', 'Duronto', 'Garib Rath', 'Superfast', 'Intercity', 'Jan Shatabdi', 'Humsafar', 'Tejas', 'Vande Bharat']

def generate_time():
    hour = random.randint(0, 23)
    minute = random.choice(['00', '15', '30', '45'])
    return f"{hour:02d}:{minute}"

conn = sqlite3.connect('rtrs.db')
cursor = conn.cursor()

cursor.execute('DROP TABLE IF EXISTS trains')
cursor.execute('DROP TABLE IF EXISTS bookings')

cursor.execute('''
CREATE TABLE IF NOT EXISTS trains (
    train_no INTEGER PRIMARY KEY,
    train_name TEXT NOT NULL,
    source TEXT NOT NULL,
    destination TEXT NOT NULL,
    departure_time TEXT NOT NULL,
    arrival_time TEXT NOT NULL,
    seats_available INTEGER NOT NULL
)
''')

cursor.execute('''
CREATE TABLE IF NOT EXISTS bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    passenger_name TEXT NOT NULL,
    train_no INTEGER NOT NULL,
    seats_booked INTEGER NOT NULL,
    booking_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (train_no) REFERENCES trains(train_no)
)
''')

trains = []
for train_no in range(1001, 11001):
    source = random.choice(cities)
    destination = random.choice([city for city in cities if city != source])
    train_name = f"{random.choice(train_prefixes)} Express"
    departure_time = generate_time()
    arrival_time = generate_time()
    seats_available = random.randint(50, 300)
    trains.append((train_no, train_name, source, destination, departure_time, arrival_time, seats_available))

cursor.executemany('INSERT INTO trains VALUES (?, ?, ?, ?, ?, ?, ?)', trains)
conn.commit()
conn.close()
print("Database created with 10,000 trains.")